package com.example.authapp;
public class User {
    public String usernamev, passv;
    public  User(){

    }

    public User(String usernamev, String passv){
       this.usernamev = usernamev;
       this.passv = passv;

    }
}
